import tkinter as tk
from caculate import caculate
import pathlib
import pandas as pd

root= tk.Tk()
root.title('DU LỊCH SUỐI TÂN ĐÌNH')
canvas1 = tk.Canvas(root, width = 500, height = 600,  relief = 'raised')
canvas1.pack()


label0 = tk.Label(root, text='TÍNH TOÁN DÙNG SAI PHÂN ẨN')
label0.config(font=('helvetica', 14))
canvas1.create_window(250, 25, window=label0)


label1 = tk.Label(root, text='Nhập L:')
label1.config(font=('helvetica', 10))
canvas1.create_window(250, 50, window=label1)

entry1 = tk.Entry (root) 
canvas1.create_window(250, 70, window=entry1)


label2 = tk.Label(root, text='Nhập C00:')
label2.config(font=('helvetica', 10))
canvas1.create_window(250, 100, window=label2)

entry2 = tk.Entry (root) 
canvas1.create_window(250, 120, window=entry2)


label3 = tk.Label(root, text='Nhập D00:')
label3.config(font=('helvetica', 10))
canvas1.create_window(250, 150, window=label3)

entry3 = tk.Entry (root) 
canvas1.create_window(250, 170, window=entry3)


label4 = tk.Label(root, text='Nhập u:')
label4.config(font=('helvetica', 10))
canvas1.create_window(250, 200, window=label4)

entry4 = tk.Entry (root) 
canvas1.create_window(250, 220, window=entry4)


label5 = tk.Label(root, text='Nhập tt:')
label5.config(font=('helvetica', 10))
canvas1.create_window(250, 250, window=label5)

entry5 = tk.Entry (root) 
canvas1.create_window(250, 270, window=entry5)


label6 = tk.Label(root, text='Nhập dentaX:')
label6.config(font=('helvetica', 10))
canvas1.create_window(250, 300, window=label6)

entry6 = tk.Entry (root) 
canvas1.create_window(250, 320, window=entry6)


label7 = tk.Label(root, text='Nhập dentaT:')
label7.config(font=('helvetica', 10))
canvas1.create_window(250, 350, window=label7)

entry7 = tk.Entry (root) 
canvas1.create_window(250, 370, window=entry7)


label8 = tk.Label(root, text='Nhập e:')
label8.config(font=('helvetica', 10))
canvas1.create_window(250, 400, window=label8)

entry8 = tk.Entry (root) 
canvas1.create_window(250, 420, window=entry8)


label9 = tk.Label(root, text='Nhập d:')
label9.config(font=('helvetica', 10))
canvas1.create_window(250, 450, window=label9)

entry9 = tk.Entry (root) 
canvas1.create_window(250, 470, window=entry9)

label10 = tk.Label(root, text='Nhập k:')
label10.config(font=('helvetica', 10))
canvas1.create_window(250, 500, window=label10)

entry10 = tk.Entry (root) 
canvas1.create_window(250, 520, window=entry10)
def getData():
    df = pd.read_excel('/Users/truongducan/Desktop/Test4/DLSuoiTanDinh2.xlsx', index_col=0, header=1)
    for i in range(24):
        L = entry1.get()
        C00 = df.L00[i]
        D00 = df.D00[i]
        u = entry4.get()
        tt = entry5.get()
        dentaX = entry6.get()
        dentaT = entry7.get()
        e = entry8.get()
        d = entry9.get()
        k = entry10.get()

        if not L: L = '1'
        if not C00: C00 = C00
        if not D00: D00 = D00
        if not u: u = '0.1'
        if not tt: tt = '1'
        if not dentaX: dentaX = '100'
        if not dentaT: dentaT = '240'
        if not e: e = '20'
        if not d: d = '0.5'
        if not k: k = '0.000001157'
        result = caculate(i,float(L),float(C00),float(D00),float(u),float(tt),float(dentaX),float(dentaT),float(e),float(d),float(k))

        # f = open(str(pathlib.Path(__file__).parent)+f"/result_L00={str(C00)}_D00={str(D00)}.csv", "w")

        # rowSize = len(result)
        # colSize = len(result[0])
        # for i in range(rowSize):
        #     for j in range(colSize):
        #         if j == colSize-1: f.write(str(result[i][j]))
        #         else: f.write(str(result[i][j])+",")
        #     f.write("\n")
        # f.close()

        label11 = tk.Label(root, text= 'Kết quả lưu trong file ' + str(pathlib.Path(__file__).parent),font=('helvetica', 10))
        canvas1.create_window(250, 580, window=label11)

    
    
    
button1 = tk.Button(text='Xem kết quả', command=getData, font=('helvetica', 14, 'bold'))
canvas1.create_window(250, 550, window=button1)

root.mainloop()