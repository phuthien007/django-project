import matplotlib.pyplot as plt
import matplotlib.animation as anim
from  matplotlib.animation import FuncAnimation
import numpy as np
import pathlib
plt.rcParams['animation.ffmpeg_path'] = '/Users/truongducan/Downloads/ffmpeg'

# result: Danh sách các vector cần vẽ
# title_mat: Danh sách tên biểu đồ
# xlabel: Tên của trục hoành
# ylabel: Tên của trục tung
# len_x : độ dài liên tục < giá trị len_x ở trục hoành
# len_y : độ dài liên tục < giá trị len_y ở trục tung
# hàm draw_matplot: vẽ đồ thị
'''
from animation_matplotlib import draw_matplot
rồi dùng như 1 hàm bình thường
'''
def draw_matplot(D00, C00,result, title_mat=['1','2','3','4','5','6','7','8','9','10'],value=11, xlabel='X', ylabel='Y', min_x=0, min_y=0,len_x=2100, len_y=11, matrixName="D0" ):
    fig, ax = plt.subplots()
    fig.set_tight_layout(True)
    ax.set_xlim(min_x, len_x+100)
    ax.set_ylim(min_y, len_y+1)
    line, = ax.plot(0,0 ,'or-')
    x_data = np.arange(min_x, len_x+100, (len_x+100-min_x)/value)
    def animate(i):
        label= title_mat[i]
        y_data= result[i]
        line.set_xdata(x_data)
        line.set_ydata(y_data)
        ax.set_title("Số nút thời gian: " + label)
        return line,ax
    ani = FuncAnimation(fig, func=animate,repeat=True ,frames=np.arange(0,len(result),1), interval=2000)
    # plt.tight_layout()
    plt.title("Biểu Đồ Trực Quan")
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid()
    # plt.show()

    Writer = anim.writers['ffmpeg']
    writer = Writer(fps=1, metadata={'artist': 'Truong Duc An'}, bitrate=1800)
    ani.save(str(pathlib.Path(__file__).parent)+f"/result_with_D00={str(D00)}_L00={str(C00)}_{matrixName}.mp4", writer)


 
#draw_matplot([np.random.randint(0,11,11) for i in range(5)])