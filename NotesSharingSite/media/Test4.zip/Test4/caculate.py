import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pathlib
from animation_matplotlib import draw_matplot

def caculate(tam, L=1, C00=10, D00=10, u=0.1, tt=1, dentaX=100, dentaT=240, e=20, d=0.5, k=0.1):
    # Tính toán các thông số

    k2=0.00000118

    # Tính toán các thông số
    N = L * 1000 / dentaX
    M = tt * 3600 / dentaT
    a = u * dentaT / dentaX
    D = e * dentaT / ((dentaX) ** 2)
    AP = 1 + 2 * d * D
    AE = d * (D - 0.5 * a - 0.5 * k)
    AW = d * (0.5 * a + D) - 0.5 * k * (1 - d)

    # Lập ma trận A
    A = np.zeros((int(N), int(N)))
    np.fill_diagonal(A, AP)
    np.fill_diagonal(A[:-1, 1:], -AE)
    np.fill_diagonal(A[1:, :-1], -AW)
    A[0][0] = 1
    A[int(N) - 1][int(N) - 1] = 1
    A[0][1] = 0
    A[int(N) - 1][int(N) - 2] = -1
    # print(A)

    # Thiết lập các vecto,ma trận tính toán
    matrixL = np.zeros((int(N) + 1) * (int(M) + 1))
    matrixL = np.reshape(matrixL, (int(M) + 1, int(N) + 1))
    result = np.zeros((int(N) + 1) * (int(M) + 1))
    result = np.reshape(result, (int(M) + 1, int(N) + 1))
    SCR1 = np.zeros(int(N))
    SCR2 = np.zeros(int(N))
    T1 = np.zeros(int(N))
    T2 = np.zeros(int(N))
    C0 = np.zeros(int(N) + 1)
    D0 = np.zeros(int(N) + 1)
    matrixL[0, 0] = C00
    result[0, 0] = D00
    C0[0] = C00
    D0[0] = C00

    for i in range(1, (int(M) + 1)):
        for j in range(1, (int(N) - 1)):
            # SCR1[j] = C0[j] - 0.5*(1-d)*a*(C0[j+1]-C0[j-1]) + (1-d)*D*(C0[j+1]-2*C0[j]+C0[j-1]) - 0.5*k*(d*C0[j+1]+(1-d)*C0[j-1])
            # SCR1[j] = C0[j-1]*(0.5*(1-d)*a+(1-d)*D-0.5*k*(1-d))+C0[j]*(-2*(1-d)*D + 1) + C0[j+1]*(-0.5*(1-d)*a+(1-d)*D-0.5*k*d)
            SCR1[j] = AE * C0[j + 1] + AW * C0[j - 1] + (1 - AE - AW) * C0[j]
        SCR1[0] = C00
        SCR1[int(N) - 1] = 0
        print(SCR1)
        T1 = np.linalg.inv(A) @ np.transpose(SCR1)
        print("T1 = A-1 * SCR = \n", T1)

        for k in range(0, int(N)): matrixL[i, k + 1] = T1[k]
        matrixL[i, 0] = C00
        for t in range(0, int(N) - 1):
            C0[(1 + t)] = T1[t]
        C0[0] = C00


    result1d = np.ravel(matrixL)
    max_y = max(result1d)
    min_y = min(result1d)

    title_mat = []
    for i in range(1, int(M + 2)): title_mat.append(str(i))

    draw_matplot(D00, C00, matrixL, title_mat, value=len(matrixL[0]), xlabel='X', ylabel='Y', min_x=0, min_y=min_y,
                 len_x=2000, len_y=max_y,matrixName="matrixL")
    writer = pd.ExcelWriter(str(pathlib.Path(__file__).parent)+"/result_of_"+str(tam)+"_hours_matrixL.xlsx", engine='xlsxwriter')
    header1 = [str(i) for i in range(0, int(L * 1000 + dentaX), int(dentaX))]
    index1 = [str(i) for i in range(0, int(tt * 3600 + dentaT), int(dentaT))]
    res1 = pd.DataFrame(data=matrixL, index=index1, columns=header1)
    res2 = pd.DataFrame(data=C0, columns=['L0'])
    res3 = pd.DataFrame(data=D0, columns=['D0'])
    res1.to_excel(writer, sheet_name=f"result_of_{tam}hours", startcol=3, startrow=3)
    res2.to_excel(writer, index=False, sheet_name=f"result_of_{tam}hours_L00={round(C00, 7)}")
    res3.to_excel(writer, index=False, sheet_name=f"result_of_{tam}hours_D00={round(D00, 7)}")
    writer.save()



    AE = d * (D - 0.5 * a - 0.5 * k2)
    AW = d * (0.5 * a + D) - 0.5 * k2 * (1 - d)
    # Lập ma trận A
    A = np.zeros((int(N), int(N)))
    np.fill_diagonal(A, AP)
    np.fill_diagonal(A[:-1, 1:], -AE)
    np.fill_diagonal(A[1:, :-1], -AW)
    A[0][0] = 1
    A[int(N) - 1][int(N) - 1] = 1
    A[0][1] = 0
    A[int(N) - 1][int(N) - 2] = -1

    
    for h in range(0, int(M)):
        for m in range(1, (int(N) - 1)):
            SCR2[m] = AE * D0[m + 1] + AW * D0[m - 1] + (1 - AE - AW) * D0[m] + 0.5 * 0. * ((d * matrixL[h+1][m + 1] + (1 - d) * matrixL[h+1][m-1]) + (d * matrixL[h][m + 1] + (1 - d) * matrixL[h][m - 1]))
            # SCR2[m] = D0[m]-0.5*(1-d)*a*(D0[m+1]-D0[m-1])+(1-d)*D*(D0[m+1]-2*D0[m]+D0[m-1])-0.5*k*(d*D0[m+1]+(1-d)*D0[m-1]) + 0.5*k*(d*matrixL[h+1][m+1]+(1-d)*matrixL[h+1][m-1]) +(d*matrixL[h][m+1] +(1-d)*matrixL[h][m-1])
        SCR2[0] = D00 #+ 0.5 * k * ((d * matrixL[h+1][m + 1] + (1 - d) * matrixL[h+1][m - 1]) + (d * matrixL[h][m + 1] + (1 - d) * matrixL[h][m - 1]))
        SCR2[int(N) - 1] = 0  #+ 0.5 * k * ((d * matrixL[h+1][m + 1] + (1 - d) * matrixL[h+1][m - 1]) + (d * matrixL[h][m + 1] + (1 - d) * matrixL[h][m - 1]))
        # print(SCR2)
        T2 = np.linalg.inv(A) @ np.transpose(SCR2)
        # print("T2 = A-1 * SCR = \n",T2)

        for k in range(0, int(N)): result[h + 1, k + 1] = T2[k]
        result[h + 1, 0] = D00
        for t in range(0, int(N) - 1):
            D0[(1 + t)] = T2[t]
        D0[0] = D00

    result1d = np.ravel(result)
    max_y = max(result1d)
    min_y = min(result1d)
    # print(result)

    # tạo arr chứa số lượng dòng
    # print(title_mat)

    # vẽ đồ thị và xuất ra file mp4
    # draw_matplot(result,title_mat,xlabel='X',ylabel='Y',min_x=0,min_y=min_y,len_x=2100, len_y=max_y)
    draw_matplot(D00, C00, result, title_mat, value=len(result[0]), xlabel='X', ylabel='Y', min_x=0, min_y=min_y,
                 len_x=2000, len_y=max_y,matrixName="D0")
    writer = pd.ExcelWriter(str(pathlib.Path(__file__).parent)+"/result_of_"+str(tam)+"_hours_D0.xlsx", engine='xlsxwriter')
    header1 = [str(i) for i in range(0, int(L * 1000 + dentaX), int(dentaX))]
    index1 = [str(i) for i in range(0, int(tt * 3600 + dentaT), int(dentaT))]
    res1 = pd.DataFrame(data=result, index=index1, columns=header1)
    res2 = pd.DataFrame(data=C0, columns=['L0'])
    res3 = pd.DataFrame(data=D0, columns=['D0'])
    res1.to_excel(writer, sheet_name=f"result_of_{tam}hours", startcol=3, startrow=3)
    res2.to_excel(writer, index=False, sheet_name=f"result_of_{tam}hours_L00={round(C00, 7)}")
    res3.to_excel(writer, index=False, sheet_name=f"result_of_{tam}hours_D00={round(D00, 7)}")
    writer.save()
    return result

# writer = pd.ExcelWriter("result.xlsx", engine='xlsxwriter')
#qqq = caculate(1,L=1, C00=10, D00=10, u=0.1, tt=1, dentaX=100, dentaT=240, e=20, d=0.5, k=0.1)
# print(qqq)
